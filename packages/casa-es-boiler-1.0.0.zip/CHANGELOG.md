# Changelog — Casa ES Boiler

## [1.0.0] - 2026-09-12
### Added
- Current water temperature.
- Dynamic card color while the boiler is heating.
