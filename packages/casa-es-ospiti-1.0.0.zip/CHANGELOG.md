# Changelog — Casa ES Guest Mode

## [1.0.0] - 2026-09-12
### Added
- Live guest mode status and toggle.
- Reminder information for the Casa ES automation.
