# Changelog — Casa ES Low Batteries

## [2.0.0] - 2026-09-12
### Added
- Automatic discovery of Home Assistant battery sensors.
- Configurable low-battery threshold and detailed device list.
- Exclusion of photovoltaic storage batteries by default.

## [1.1.0] - 2026-06-08
### Added
- Quick battery check button.
